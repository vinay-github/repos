#define KER_O "KERNEL"
#define KER_C "/bin/uname -a"
#define KER_K "kernel"

#define MEM_O "MEMINFO"
#define MEM_TOTAL_C  "/bin/cat /proc/meminfo | grep -i Memtotal | awk '{print $2 $3}'"
#define MEM_TOTAL_K "Memory_Total"

#define MEM_FREE_C  "/bin/cat /proc/meminfo | grep -i Memfree | awk '{print $2 $3}'"
#define MEM_FREE_K "Memory_Free"

#define MEM_BUF_C  "/bin/cat /proc/meminfo | grep -i buffers | awk '{print $2 $3}'"
#define MEM_BUF_K "Buffers"

#define MEM_CACHE_C  "/bin/cat /proc/meminfo | grep -i cached | awk '{print $2 $3}' | head -1"
#define MEM_CACHE_K "Cached"

#define MEM_SWAP_CACHE_C  "/bin/cat /proc/meminfo | grep -i swapcached | awk '{print $2 $3}'"
#define MEM_SWAP_CACHE_K "Swap_Cached"

/*#define MEM_ACT_C "/bin/cat /proc/meminfo | grep -iw active: | awk '{print $2 $3}'"
#define MEM_ACT_K "Active"

#define MEM_INACT_C "/bin/cat /proc/meminfo | grep -iw inactive: | awk '{print $2 $3}'"
#define MEM_INACT_K "Inactive"

#define MEM_ACT_ANON_C "/bin/cat /proc/meminfo | grep -iw 'active(anon' | awk '{print $2 $3}'"
#define MEM_ACT_ANON_K "Active_Anon"

#define MEM_INACT_ANON_C "/bin/cat /proc/meminfo | grep -i 'inactive(anon' | awk '{print $2 $3}'"
#define MEM_INACT_ANON_K "Inactive_Anon"

#define MEM_ACT_FILE_C "/bin/cat /proc/meminfo | grep -i 'active(file' | awk '{print $2 $3}'"
#define MEM_ACT_FILE_K "Active_File"

#define MEM_INACT_FILE_C "/bin/cat /proc/meminfo | grep -i 'inactive(file' | awk '{print $2 $3}'"
#define MEM_INACT_FILE_K "Inactive_File"

#define MEM_UNEVIC_C "/bin/cat /proc/meminfo | grep -iw unevictable | awk '{print $2 $3}'"
#define MEM_UNEVIC_K "Unevictable"

#define MEM_MLOCK_C "/bin/cat /proc/meminfo | grep -iw mlocked | awk '{print $2 $3}'"
#define MEM_MLOCK_K "Mlocked"

#define MEM_SWAP_TOTAL_C "/bin/cat /proc/meminfo | grep -iw swaptotal | awk '{print $2 $3}'"
#define MEM_SWAP_TOTAL_K "Swap_Total"

#define MEM_SWAP_FREE_C "/bin/cat /proc/meminfo | grep -iw swapfree | awk '{print $2 $3}'"
#define MEM_SWAP_FREE_K "Swap_Free"

#define MEM_DIRTY_C "/bin/cat /proc/meminfo | grep -iw dirty | awk '{print $2 $3}'"
#define MEM_DIRTY_K "Dirty"

#define MEM_WRITE_BACK_C "/bin/cat /proc/meminfo | grep -iw writeback | awk '{print $2 $3}'"
#define MEM_WRITE_BACK_K "Write_Back"

#define MEM_ANON_PAGES_C "/bin/cat /proc/meminfo | grep -i anonpage | awk '{print $2 $3}'"
#define MEM_ANON_PAGES_K "AnonPages"
*/
#define MEM_MAP_C "/bin/cat /proc/meminfo | grep -iw mapped | awk '{print $2 $3}'"
#define MEM_MAP_K "Mapped"

#define MEM_SHMEM_C "/bin/cat /proc/meminfo | grep -i shmem | awk '{print $2 $3}'"
#define MEM_SHMEM_K "Shmem"

/*#define MEM_SLAB_C "/bin/cat /proc/meminfo | grep -iw slab | awk '{print $2 $3}'"
#define MEM_SLAB_K "Slab"

#define MEM_SRECLAIMABLE_C "/bin/cat /proc/meminfo | grep -iw sreclaimable | awk '{print $2 $3}'"
#define MEM_SRECLAIMABLE_K "SReclaimable"

#define MEM_SUNRECLAIM_C "/bin/cat /proc/meminfo | grep -iw sunreclaim | awk '{print $2 $3}'"
#define MEM_SUNRECLAIM_K "SUnreclaim"*/

#define MEM_KERNEL_STACK_C "/bin/cat /proc/meminfo | grep -iw kernelstack | awk '{print $2 $3}'"
#define MEM_KERNEL_STACK_K "Kernel_Stack"

#define MEM_PAGE_TABLES_C "/bin/cat /proc/meminfo | grep -iw pagetables | awk '{print $2 $3}'"
#define MEM_PAGE_TABLES_K "PageTables"

/*#define MEM_NFS_C "/bin/cat /proc/meminfo | grep -i nfs | awk '{print $2 $3}'"
#define MEM_NFS_K "NFS"

#define MEM_BOUNCE_C "/bin/cat /proc/meminfo | grep -iw bounce | awk '{print $2 $3}'"
#define MEM_BOUNCE_K "Bounce"

#define MEM_COMMITTED_AS_C "/bin/cat /proc/meminfo | grep -iw committed | awk '{print $2 $3}'"
#define MEM_COMMITTED_AS_K "Committed_AS"
*/
#define MEM_VMALLOC_TOTAL_C "/bin/cat /proc/meminfo | grep -iw vmalloctotal | awk '{print $2 $3}'"
#define MEM_VMALLOC_TOTAL_K "VMallocTotal"

#define MEM_VMALLOC_USED_C "/bin/cat /proc/meminfo | grep -iw vmallocused | awk '{print $2 $3}'"
#define MEM_VMALLOC_USED_K "VMallocUsed"

#define MEM_VMALLOC_CHUNK_C "/bin/cat /proc/meminfo | grep -iw vmallocchunk | awk '{print $2 $3}'"
#define MEM_VMALLOC_CHUNK_K "VMallocChunk"

#define INOUT_O "IN_OUT"
#define ETH02_O "ETH0_2"

#define ETH02_BYTES_R_C "/bin/cat /proc/eth0.2 | grep 'bytes received' | awk '{print $4}'"
#define ETH02_BYTES_R_K "Bytes_Received"

#define ETH02_FRAMES_R_C "/bin/cat /proc/eth0.2 | grep 'frames received' | awk '{print $4}'"
#define ETH02_FRAMES_R_K "frames_received"

#define ETH02_BROAD_MULTI_R_C "/bin/cat /proc/eth0.2 | grep -i multicast | awk '{print $3}'"
#define ETH02_BROAD_MULTI_R_K "Broadcast-Multicast_Received"

#define ETH02_BYTES_T_C "/bin/cat /proc/eth0.2 | grep 'bytes transmitted' | awk '{print $4}'"
#define ETH02_BYTES_T_K "Bytes_Transmitted"

#define ETH02_FRAMES_T_C "/bin/cat /proc/eth0.2 | grep 'frames transmitted' | awk '{print $4}'"
#define ETH02_FRAMES_T_K "frames_transmitted"

#define ETH02_DEVICE_C "/bin/cat /proc/eth0.2 | grep -i device | awk '{print $2}'"
#define ETH02_DEVICE_K "Device"

#define ETH01_O "ETH0_1"

#define ETH01_BYTES_R_C "/bin/cat /proc/eth0.1 | grep 'bytes received' | awk '{print $4}'"
#define ETH01_BYTES_R_K "Bytes_Received"

#define ETH01_FRAMES_R_C "/bin/cat /proc/eth0.1 | grep 'frames received' | awk '{print $4}'"
#define ETH01_FRAMES_R_K "frames_received"

#define ETH01_BROAD_MULTI_R_C "/bin/cat /proc/eth0.1 | grep -i multicast | awk '{print $3}'"
#define ETH01_BROAD_MULTI_R_K "Broadcast-Multicast_Received"

#define ETH01_BYTES_T_C "/bin/cat /proc/eth0.1 | grep 'bytes transmitted' | awk '{print $4}'"
#define ETH01_BYTES_T_K "Bytes_Transmitted"

#define ETH01_FRAMES_T_C "/bin/cat /proc/eth0.1 | grep 'frames transmitted' | awk '{print $4}'"
#define ETH01_FRAMES_T_K "frames_transmitted"

#define ETH01_DEVICE_C "/bin/cat /proc/eth0.1 | grep -i device | awk '{print $2}'"
#define ETH01_DEVICE_K "Device"

#define OTHER_O "OTHER_INFO"

#define UPTIME_C "/usr/bin/uptime  | awk -F , '{print $1}'"
#define UPTIME_K "Uptime"

#define LOADAVG_C "/usr/bin/uptime  | awk '{print $8 $9 $10}'"
#define LOADAVG_K "Load_avg"


#define WLAN1_CAP "/usr/sbin/iw dev wlan1 station dump > /tmp/wlan1.txt"
#define WLAN0_CAP "/usr/sbin/iw dev wlan0 station dump > /tmp/wlan0.txt"

#define NO_WLAN1 "/bin/cat /tmp/wlan1.txt | grep -i station | wc -l"
#define NO_WLAN0 "/bin/cat /tmp/wlan0.txt | grep -i station | wc -l"

#define WLAN_USERS_O "WLAN_USERS"
#define WLAN0_O "WLAN0"
#define WLAN1_O "WLAN1"

#define STATION_ID_0 "/bin/cat /tmp/wlan0.txt | grep -i station | awk '{print $2}' | head -%d | tail -1"
#define STATION_ID_1 "/bin/cat /tmp/wlan1.txt | grep -i station | awk '{print $2}' | head -%d | tail -1"
#define ID_K "ID"
#define ID1_K "ID"

#define RX_BYTES_0 "/bin/cat /tmp/wlan0.txt | grep -i 'rx bytes' | awk '{print $3}' | head -%d | tail -1"
#define RX_BYTES_1 "/bin/cat /tmp/wlan1.txt | grep -i 'rx bytes' | awk '{print $3}' | head -%d | tail -1"
#define RX_B_K "RX_BYTES"
#define RX_B1_K "RX_BYTES"

#define TX_BYTES_0 "/bin/cat /tmp/wlan0.txt | grep -i 'tx bytes' | awk '{print $3}' | head -%d | tail -1"
#define TX_BYTES_1 "/bin/cat /tmp/wlan1.txt | grep -i 'tx bytes' | awk '{print $3}' | head -%d | tail -1"
#define TX_B_K "TX_BYTES"
#define TX_B1_K "TX_BYTES"

#define RX_PACKETS_0 "/bin/cat /tmp/wlan0.txt | grep -i 'rx packets:' | awk '{print $3}' | head -%d | tail -1"
#define RX_PACKETS_1 "/bin/cat /tmp/wlan1.txt | grep -i 'rx packets:' | awk '{print $3}' | head -%d | tail -1"
#define RX_PAC_K "RX_PACKETS"
#define RX_PAC1_K "RX_PACKETS"

#define TX_PACKETS_0 "/bin/cat /tmp/wlan0.txt | grep -i 'tx packets:' | awk '{print $3}' | head -%d | tail -1"
#define TX_PACKETS_1 "/bin/cat /tmp/wlan1.txt | grep -i 'tx packets:' | awk '{print $3}' | head -%d | tail -1"
#define TX_PAC_K "TX_PACKETS"
#define TX_PAC1_K "TX_PACKETS"

#define SIGNAL_0 "/bin/cat /tmp/wlan0.txt | grep -i 'signal:' | awk '{print $2 $3}' | head -%d | tail -1"
#define SIGNAL_1 "/bin/cat /tmp/wlan1.txt | grep -i 'signal:' | awk '{print $2 $3}' | head -%d | tail -1"
#define SIG_K "SIGNAL"
#define SIG1_K "SIGNAL"

#define SIGNAL_AVG_0 "/bin/cat /tmp/wlan0.txt | grep -i 'signal avg:' | awk '{print $3 $4}' | head -%d | tail -1"
#define SIGNAL_AVG_1 "/bin/cat /tmp/wlan1.txt | grep -i 'signal avg:' | awk '{print $3 $4}' | head -%d | tail -1"
#define SIG_AVG_K "SIGNAL_AVG"
#define SIG_AVG1_K "SIGNAL_AVG"

#define TX_BITRATE_0 "/bin/cat /tmp/wlan0.txt | grep -i 'tx bitrate:' | awk '{print $3 $4 $5 $6}' | head -%d | tail -1"
#define TX_BITRATE_1 "/bin/cat /tmp/wlan1.txt | grep -i 'tx bitrate:' | awk '{print $3 $4 $5 $6}' | head -%d | tail -1"
#define TX_BIT_K "TX_BITRATE"
#define TX_BIT1_K "TX_BITRATE"

#define RX_BITRATE_0 "/bin/cat /tmp/wlan0.txt | grep -i 'rx bitrate:' | awk '{print $3 $4 $5 $6}' | head -%d | tail -1"
#define RX_BITRATE_1 "/bin/cat /tmp/wlan1.txt | grep -i 'rx bitrate:' | awk '{print $3 $4 $5 $6}' | head -%d | tail -1"
#define RX_BIT_K "RX_BITRATE"
#define RX_BIT1_K "RX_BITRATE"
