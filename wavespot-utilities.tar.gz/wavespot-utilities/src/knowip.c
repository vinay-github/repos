
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <sys/select.h>
#include <stdio.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <syslog.h>
#include <errno.h>

int sock_read (int sock_fd, uint8_t *p_msg, uint32_t len)
{

    int nbytes;
    int total_bytes = 0;
    uint32_t read_len;

    memset(p_msg, 0, len);
    read_len = len;
    do {
        if ((nbytes = read(sock_fd, ((uint8_t *)p_msg + total_bytes), 
            read_len)) == -1) {
            if (errno != EINTR) {
                return -1;
            }
            continue;
        }
        if (nbytes == 0) {
            return -1;
        }
        total_bytes += nbytes;
        read_len -= nbytes;
        if (total_bytes == len) {
            return total_bytes;
        }

    } while (total_bytes < len);
    return -1;
}
/* the function is used to obtain the Public Routable
 * PHC Ip from the knowipd daemon 
 * remote_ip_host - ip address of remote host.
 * return value is in_addt_t ( which is uint32_t inetinet/in.h)
 */

int main(int argc, char *argv[])
{

	struct hostent *hp;
	char ch, * remote_ip_host = NULL;
	struct sockaddr_in connect_to;
	in_addr_t received_addr;
	struct in_addr tmp_addr;
	int sock;
	fd_set rfds;
	int retval;
	struct timeval tv;
	uint16_t remote_ip_host_port = 0;

	while ((ch = getopt(argc, argv, "i:p:")) != EOF){
		switch (ch){
			case 'i':
				remote_ip_host = (char *)strndup(optarg, strlen(optarg));
				break;
			case 'p':
				remote_ip_host_port = (u_short)atoi(optarg);
				break;
			default:
				syslog(LOG_DEBUG, "Unknown argument type %c", ch);
				exit(1);
		}
	}
	if (remote_ip_host == NULL) {
		exit(1);
	}

	FD_ZERO(&rfds);
	/* Wait up to ten seconds if the read blocks */
	tv.tv_sec = 10;
	tv.tv_usec = 0;

	sock = socket(PF_INET, SOCK_STREAM, 0);
	if (sock < 0) {
		exit(1);;
	}

	FD_SET(sock, &rfds);
	hp = gethostbyname(remote_ip_host);
	if (hp == NULL) {
		syslog(LOG_DEBUG, "gethostbyname(%s): %s", remote_ip_host,
				strerror(errno));
		close(sock);
		exit(1);
	}
	memset(&connect_to, 0, sizeof(connect_to));

	connect_to.sin_family = AF_INET;
	connect_to.sin_port = htons(remote_ip_host_port);
	memcpy(&connect_to.sin_addr.s_addr, hp->h_addr, sizeof(in_addr_t));

	if (connect(sock, (struct sockaddr *)&connect_to, sizeof(connect_to))
			< 0) {
		syslog(LOG_DEBUG, "connect() failed: %s", strerror(errno));
		close(sock);
		exit(1);
	}
	retval = select(sock+1, &rfds, NULL, NULL, &tv);
	if (retval < 0) {
		exit(1);
	}
	if (retval == 0) {
		/* select timeout */
		close(sock);
		exit(1);
	}
	if (retval > 0) {
		if (FD_ISSET(sock, &rfds)) {
			/* Assumed that, read returns 4 Bytes */
			if (sock_read(sock, (uint8_t *)&received_addr, sizeof(received_addr)) 
					< 0) {
				close(sock);
				exit(1);
			}
			/* read success */
			close(sock);
			tmp_addr.s_addr = received_addr;
			printf("%s\n",inet_ntoa(tmp_addr));
			exit(0);
		}
	}
	close(sock);
	exit(1);

}
