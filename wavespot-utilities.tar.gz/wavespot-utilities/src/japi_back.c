#include <stdio.h>
#include <stdlib.h>
#include <json/json.h>
#include <string.h>

#include "info.h"

#define TYPE_R "r"


struct get_info
{
	char* command;
	char* info_name;
	char* obj_name;
};

void get_mem_info(json_object *,char *,struct get_info);
void get_in_out_info(json_object *,char *,struct get_info);
void get_other_info(json_object *,char *,struct get_info);
void get_users_info(json_object *,char *,struct get_info);

int main( int argc, char *argv[] )
{

	FILE *fp;	
	char type_r[]=TYPE_R;
	struct get_info assign;

	/* json parent object creation */
	json_object * obj = json_object_new_object();

	/* For memory information */
	get_mem_info(obj,type_r,assign);
	
	/* For Data Transmit informations */
	get_in_out_info(obj,type_r,assign);

	/* For other informations like uptime, loadavg and users connected */
	get_other_info(obj,type_r,assign);
	
	get_users_info(obj,type_r,assign);

	printf("%s\n", json_object_to_json_string(obj));
	if((fp=fopen("./json_data","w")) !=NULL) {
		fprintf(fp,"%s\n",json_object_to_json_string(obj));
		fclose(fp);
	}
	
	return 0;
}

void get_users_info(json_object *obj,char * type_r,struct get_info assign)
{
	FILE *f,*f2;
	char wlan1_users[]=WLAN1_CAP;
	char wlan0_users[]=WLAN0_CAP;
	char no_wlan1[]=NO_WLAN1;
	char no_wlan0[]=NO_WLAN0;
	char pa[5],pa2[5],object[256],info[256];
	int num=0,num2=0,l;


	json_object * obj_user = json_object_new_object();
	
	popen(wlan0_users,"r");
	assign.obj_name = WLAN0_O;

	json_object * obj_user_child = json_object_new_object();
	json_object_object_add(obj_user,assign.obj_name,obj_user_child);
	
	f=popen(no_wlan0,"r");
	fgets(pa,sizeof(pa),f);
	num=atoi(pa);
	for(l=1;l<=num;l++)
	{
		json_object * obj_wlan0 = json_object_new_object();
		
		memset(object,'\0',sizeof(object));
		snprintf(object,sizeof(object),"CLIENT_%d",l);
		assign.obj_name = object;
		json_object_object_add(obj_user_child,assign.obj_name,obj_wlan0);

		assign.obj_name = WLAN_USERS_O;
			
		snprintf(object,sizeof(object),STATION_ID_0,l);
		assign.command = object; 
		assign.info_name = ID_K;
		fun(assign.command,type_r,obj_wlan0,assign.info_name,obj,assign.obj_name);

		snprintf(object,sizeof(object),RX_BYTES_0,l); 
                assign.command = object;
                assign.info_name = RX_B_K;
                fun(assign.command,type_r,obj_wlan0,assign.info_name,obj,assign.obj_name);

		snprintf(object,sizeof(object),TX_BYTES_0,l);
                assign.command = object;
                assign.info_name = TX_B_K;
                fun(assign.command,type_r,obj_wlan0,assign.info_name,obj,assign.obj_name);

		snprintf(object,sizeof(object),RX_PACKETS_0,l);
                assign.command = object;
                assign.info_name = RX_PAC_K;
                fun(assign.command,type_r,obj_wlan0,assign.info_name,obj,assign.obj_name);

		snprintf(object,sizeof(object),TX_PACKETS_0,l);
                assign.command = object;
                assign.info_name = TX_PAC_K;
                fun(assign.command,type_r,obj_wlan0,assign.info_name,obj,assign.obj_name);

		snprintf(object,sizeof(object),INACTIVE_0,l);
                assign.command = object;
                assign.info_name = INACT_K;
                fun(assign.command,type_r,obj_wlan0,assign.info_name,obj,assign.obj_name);
		
		snprintf(object,sizeof(object),SIGNAL_0,l);
                assign.command = object;
                assign.info_name = SIG_K;
                fun(assign.command,type_r,obj_wlan0,assign.info_name,obj,assign.obj_name);

		snprintf(object,sizeof(object),SIGNAL_AVG_0,l);
                assign.command = object;
                assign.info_name = SIG_AVG_K;
                fun(assign.command,type_r,obj_wlan0,assign.info_name,obj,assign.obj_name);

		snprintf(object,sizeof(object),TX_BITRATE_0,l);
                assign.command = object;
                assign.info_name = TX_BIT_K;
                fun(assign.command,type_r,obj_wlan0,assign.info_name,obj,assign.obj_name);
		
		snprintf(object,sizeof(object),RX_BITRATE_0,l);
                assign.command = object;
                assign.info_name = RX_BIT_K;
                fun(assign.command,type_r,obj_wlan0,assign.info_name,obj,assign.obj_name);

			
	}

	






/* Wlan1 (public users) information 	*/

	popen(wlan1_users,"r");
        assign.obj_name = WLAN1_O;

        json_object * obj_user_child2 = json_object_new_object();
        json_object_object_add(obj_user,assign.obj_name,obj_user_child2);

        f2=popen(no_wlan1,"r");
        fgets(pa2,sizeof(pa2),f2);
        num2=atoi(pa2);
	printf("%d\n",num2); 
        for(l=1;l<=num2;l++)
        {
                json_object * obj_wlan1 = json_object_new_object();
		
		memset(info,'\0',sizeof(info));
                snprintf(info,sizeof(info),"CLIENT_%d",l);
                assign.obj_name = info;
                json_object_object_add(obj_user_child2,assign.obj_name,obj_wlan1);

                assign.obj_name = WLAN_USERS_O;
		memset(info,'\0',sizeof(info));
                snprintf(info,sizeof(info),STATION_ID_1,l);
                assign.command = info;
                assign.info_name = ID1_K;
                fun(assign.command,type_r,obj_wlan1,assign.info_name,obj,assign.obj_name);

                snprintf(info,sizeof(info),RX_BYTES_1,l);
                assign.command = info;
                assign.info_name = RX_B1_K;
                fun(assign.command,type_r,obj_wlan1,assign.info_name,obj,assign.obj_name);

                snprintf(info,sizeof(info),TX_BYTES_1,l);
                assign.command = info;
                assign.info_name = TX_B1_K;
                fun(assign.command,type_r,obj_wlan1,assign.info_name,obj,assign.obj_name);

                snprintf(info,sizeof(info),RX_PACKETS_1,l);
                assign.command = info;
                assign.info_name = RX_PAC1_K;
                fun(assign.command,type_r,obj_wlan1,assign.info_name,obj,assign.obj_name);

                snprintf(info,sizeof(info),TX_PACKETS_1,l);
                assign.command = info;
                assign.info_name = TX_PAC1_K;
                fun(assign.command,type_r,obj_wlan1,assign.info_name,obj,assign.obj_name);

                snprintf(info,sizeof(info),INACTIVE_1,l);
                assign.command = info;
                assign.info_name = INACT1_K;
                fun(assign.command,type_r,obj_wlan1,assign.info_name,obj,assign.obj_name);

                snprintf(info,sizeof(info),SIGNAL_1,l);
                assign.command = info;
                assign.info_name = SIG1_K;
                fun(assign.command,type_r,obj_wlan1,assign.info_name,obj,assign.obj_name);

                snprintf(info,sizeof(info),SIGNAL_AVG_1,l);
                assign.command = info;
                assign.info_name = SIG_AVG1_K;
                fun(assign.command,type_r,obj_wlan1,assign.info_name,obj,assign.obj_name);

                snprintf(info,sizeof(info),TX_BITRATE_1,l);
                assign.command = info;
                assign.info_name = TX_BIT1_K;
                fun(assign.command,type_r,obj_wlan1,assign.info_name,obj,assign.obj_name);

                snprintf(info,sizeof(info),RX_BITRATE_1,l);
                assign.command = info;
                assign.info_name = RX_BIT1_K;
                fun(assign.command,type_r,obj_wlan1,assign.info_name,obj,assign.obj_name);


        }

        json_object_object_add(obj,assign.obj_name,obj_user);




}


void get_in_out_info(json_object *obj,char * type_r,struct get_info assign)
{
	json_object * obj_in_out = json_object_new_object();
	json_object * obj_child = json_object_new_object();

                /* eth0.2's information */
		assign.obj_name = ETH02_O;
                json_object_object_add(obj_in_out,assign.obj_name,obj_child);
		
		assign.obj_name = INOUT_O;
		
		assign.command = ETH02_FRAMES_R_C;
                assign.info_name = ETH02_FRAMES_R_K;
                fun(assign.command,type_r,obj_child,assign.info_name,obj,assign.obj_name);

		assign.command = ETH02_BYTES_R_C;
                assign.info_name = ETH02_BYTES_R_K;
                fun(assign.command,type_r,obj_child,assign.info_name,obj,assign.obj_name);
	
		assign.command = ETH02_BROAD_MULTI_R_C;
                assign.info_name = ETH02_BROAD_MULTI_R_K;
                fun(assign.command,type_r,obj_child,assign.info_name,obj,assign.obj_name);

		assign.command = ETH02_FRAMES_T_C;
                assign.info_name = ETH02_FRAMES_T_K;
		fun(assign.command,type_r,obj_child,assign.info_name,obj,assign.obj_name);

		assign.command = ETH02_BYTES_T_C;
                assign.info_name = ETH02_BYTES_T_K;
                fun(assign.command,type_r,obj_child,assign.info_name,obj,assign.obj_name);

		assign.command = ETH02_DEVICE_C;
                assign.info_name = ETH02_DEVICE_K;
                fun(assign.command,type_r,obj_child,assign.info_name,obj,assign.obj_name);
		
		/* eth0.1's information */
		assign.obj_name = ETH01_O;
                json_object_object_add(obj_in_out,assign.obj_name,obj_child);

                assign.obj_name = INOUT_O;

                assign.command = ETH01_FRAMES_R_C;
                assign.info_name = ETH01_FRAMES_R_K;
                fun(assign.command,type_r,obj_child,assign.info_name,obj,assign.obj_name);

                assign.command = ETH01_BYTES_R_C;
                assign.info_name = ETH01_BYTES_R_K;
                fun(assign.command,type_r,obj_child,assign.info_name,obj,assign.obj_name);

                assign.command = ETH01_BROAD_MULTI_R_C;
                assign.info_name = ETH01_BROAD_MULTI_R_K;
                fun(assign.command,type_r,obj_child,assign.info_name,obj,assign.obj_name);

                assign.command = ETH01_FRAMES_T_C;
                assign.info_name = ETH01_FRAMES_T_K;
                fun(assign.command,type_r,obj_child,assign.info_name,obj,assign.obj_name);

                assign.command = ETH01_BYTES_T_C;
                assign.info_name = ETH01_BYTES_T_K;
                fun(assign.command,type_r,obj_child,assign.info_name,obj,assign.obj_name);
		
		assign.command = ETH01_DEVICE_C;
                assign.info_name = ETH01_DEVICE_K;
                fun(assign.command,type_r,obj_child,assign.info_name,obj,assign.obj_name);

                json_object_object_add(obj,assign.obj_name,obj_in_out);


}

void get_mem_info(json_object *obj,char * type_r,struct get_info assign)
{

	/* Kernel information */
	json_object * obj_ker = json_object_new_object();
        	assign.command = KER_C;
        	assign.info_name = KER_K;
		assign.obj_name = KER_O;
	
        	fun(assign.command,type_r,obj_ker,assign.info_name,obj,assign.obj_name);
		json_object_object_add(obj,assign.obj_name,obj_ker);	

	/* Memory Information */
	json_object * obj_ker1 = json_object_new_object();
                assign.obj_name = MEM_O;
	
		assign.command = MEM_TOTAL_C;
                assign.info_name = MEM_TOTAL_K;
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);

                assign.command = MEM_FREE_C;
                assign.info_name = MEM_FREE_K; 
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);
        
                assign.command = MEM_BUF_C;
                assign.info_name = MEM_BUF_K; 
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);
		
		assign.command = MEM_CACHE_C;
                assign.info_name = MEM_CACHE_K;      
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);

		assign.command = MEM_SWAP_CACHE_C;
                assign.info_name = MEM_SWAP_CACHE_K;      
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);

		assign.command = MEM_ACT_C;
                assign.info_name = MEM_ACT_K;      
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);

		assign.command = MEM_INACT_C;
                assign.info_name = MEM_INACT_K;      
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);

		assign.command = MEM_ACT_ANON_C;
                assign.info_name = MEM_ACT_ANON_K;      
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);

		assign.command = MEM_INACT_ANON_C;
                assign.info_name = MEM_INACT_ANON_K;      
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);

		assign.command = MEM_ACT_FILE_C;
                assign.info_name = MEM_ACT_FILE_K;      
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);

		assign.command = MEM_INACT_FILE_C;
                assign.info_name = MEM_INACT_FILE_K;      
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);

		assign.command = MEM_UNEVIC_C;
                assign.info_name = MEM_UNEVIC_K;      
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);

		assign.command = MEM_MLOCK_C;
                assign.info_name = MEM_MLOCK_K;      
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);
		
		assign.command = MEM_SWAP_TOTAL_C;
                assign.info_name = MEM_SWAP_TOTAL_K;      
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);

                assign.command = MEM_SWAP_FREE_C;
                assign.info_name = MEM_SWAP_FREE_K;
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);

                assign.command = MEM_DIRTY_C;
                assign.info_name = MEM_DIRTY_K;
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);

                assign.command = MEM_WRITE_BACK_C;
                assign.info_name = MEM_WRITE_BACK_K;
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);

                assign.command = MEM_ANON_PAGES_C;
                assign.info_name = MEM_ANON_PAGES_K;
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);

                assign.command = MEM_MAP_C;
                assign.info_name = MEM_MAP_K;
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);

                assign.command = MEM_SHMEM_C;
                assign.info_name = MEM_SHMEM_K;
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);

                assign.command = MEM_SLAB_C;
                assign.info_name = MEM_SLAB_K;
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);

                assign.command = MEM_SRECLAIMABLE_C;
                assign.info_name = MEM_SRECLAIMABLE_K;
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);

                assign.command = MEM_SUNRECLAIM_C;
                assign.info_name = MEM_SUNRECLAIM_K;
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);

                assign.command = MEM_KERNEL_STACK_C;
                assign.info_name = MEM_KERNEL_STACK_K;
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);

                assign.command = MEM_PAGE_TABLES_C;
                assign.info_name = MEM_PAGE_TABLES_K;
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);

                assign.command = MEM_NFS_C;
                assign.info_name = MEM_NFS_K;
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);

                assign.command = MEM_BOUNCE_C;
                assign.info_name = MEM_BOUNCE_K;
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);

                assign.command = MEM_COMMITTED_AS_C;
                assign.info_name = MEM_COMMITTED_AS_K;
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);
		
		assign.command = MEM_VMALLOC_TOTAL_C;
                assign.info_name = MEM_VMALLOC_TOTAL_K;
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);

		assign.command = MEM_VMALLOC_USED_C;
                assign.info_name = MEM_VMALLOC_USED_K;
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);

		assign.command = MEM_VMALLOC_CHUNK_C;
                assign.info_name = MEM_VMALLOC_CHUNK_K;
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);

		json_object_object_add(obj,assign.obj_name,obj_ker1);

}


void get_other_info(json_object *obj,char * type_r,struct get_info assign)
{
	json_object * obj_other = json_object_new_object();
                assign.obj_name = OTHER_O;

		/* Uptime information */
		assign.command = UPTIME_C;
                assign.info_name = UPTIME_K;
                fun(assign.command,type_r,obj_other,assign.info_name,obj,assign.obj_name); 

		/* Load-avg information */
                assign.command = LOADAVG_C;
                assign.info_name = LOADAVG_K; 
                fun(assign.command,type_r,obj_other,assign.info_name,obj,assign.obj_name);
                
		/* Number of users connected */
		assign.command = USERS_CONN_C;
                assign.info_name = USERS_CONN_K;
                fun(assign.command,type_r,obj_other,assign.info_name,obj,assign.obj_name);

		json_object_object_add(obj,assign.obj_name,obj_other);

	
}
