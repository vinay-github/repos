#include <json/json.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

void fun(char *cmd, char * type,json_object * obj_ker,char * id,json_object * obj, char * obj_name)
{
        FILE *fp;
        char path[50];
        int len,i;
        len=strlen(id);
        char tmp[len+1];

        for(i=0;id[i];i++)
                tmp[i]=toupper(id[i]);
        tmp[i]='\0';

        fp = popen(cmd,type);
        if (fp == NULL) {
                printf("Failed to run command\n" );
                exit;
        }

        if(fgets(path,sizeof(path),fp) != NULL) {

                /* Remove \n character */
                len=strlen(path);
                if(path[len-1]=='\n') path[len-1]='\0';

                json_object *st = json_object_new_string(path);
                json_object_object_add(obj_ker,tmp,st);

        }

}

