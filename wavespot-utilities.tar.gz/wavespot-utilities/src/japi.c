/* 	This application is used to get Wavespot controller's health in json-structure 

    	Provides informations are like memory_information, kernel_information, 
	eth0's data transmit information, wlan's data transmit informations 

Dependent files : ./j_conv.c ./info.h
*/


#include <stdio.h>
#include <stdlib.h>
#include <json/json.h>
#include <string.h>

#include "info.h"

#define TYPE_R "r"


struct get_info
{
	char* command;
	char* info_name;
	char* obj_name;
};

void get_mem_info(json_object *,char *,struct get_info);
void get_in_out_info(json_object *,char *,struct get_info);
void get_other_info(json_object *,char *,struct get_info);
void get_users_info(json_object *,char *,struct get_info);

int main( int argc, char *argv[] )
{

	FILE *fp;	
	char type_r[]=TYPE_R;
	struct get_info assign;

	/* json parent object creation */
	json_object * obj = json_object_new_object();

	/* For memory information */
	get_mem_info(obj,type_r,assign);
	
	/* For Data Transmit informations */
	get_in_out_info(obj,type_r,assign);

	/* For other informations like uptime, loadavg and users connected */
	get_other_info(obj,type_r,assign);
	
	/* For wifi(wlan0 and wlan1) connected users information */
	get_users_info(obj,type_r,assign);

	/* Printing whole data in json_structure */
	printf("%s\n", json_object_to_json_string(obj));
	
	/* Writing json structured data to a file */
	if((fp=fopen("./json_data","w")) !=NULL) {
		fprintf(fp,"%s\n",json_object_to_json_string(obj));
		fclose(fp);
	}
	
	return 0;
}

/* This function provides information regarding wlan interfaces */
void get_users_info(json_object *obj,char * type_r,struct get_info assign)
{
	FILE *f,*f2;
	char wlan1_users[]=WLAN1_CAP;
	char wlan0_users[]=WLAN0_CAP;
	char no_wlan1[]=NO_WLAN1;
	char no_wlan0[]=NO_WLAN0;
	char pa[5],pa2[5],object[256],info[256];
	int num=0,num2=0,l;

	/* Creates "Wlan object"   */
	json_object * obj_user = json_object_new_object();
	
	popen(wlan0_users,"r");
	assign.obj_name = WLAN0_O;

	/* wlan0 object (child of "Wlan object") */
	json_object * obj_user_child = json_object_new_object();
	json_object_object_add(obj_user,assign.obj_name,obj_user_child);
	
	f=popen(no_wlan0,"r");
	fgets(pa,sizeof(pa),f);
	num=atoi(pa);
	for(l=1;l<=num;l++)
	{
		/* Gets all the users information, connected to wlan0 interface */
		json_object * obj_wlan0 = json_object_new_object();
		
		memset(object,'\0',sizeof(object));
		snprintf(object,sizeof(object),"CLIENT_%d",l);
		assign.obj_name = object;
		json_object_object_add(obj_user_child,assign.obj_name,obj_wlan0);

		assign.obj_name = WLAN_USERS_O;
			
		snprintf(object,sizeof(object),STATION_ID_0,l);
		assign.command = object; 
		assign.info_name = ID_K;
		fun(assign.command,type_r,obj_wlan0,assign.info_name,obj,assign.obj_name);

		snprintf(object,sizeof(object),RX_BYTES_0,l); 
                assign.command = object;
                assign.info_name = RX_B_K;
                fun(assign.command,type_r,obj_wlan0,assign.info_name,obj,assign.obj_name);

		snprintf(object,sizeof(object),TX_BYTES_0,l);
                assign.command = object;
                assign.info_name = TX_B_K;
                fun(assign.command,type_r,obj_wlan0,assign.info_name,obj,assign.obj_name);

		snprintf(object,sizeof(object),RX_PACKETS_0,l);
                assign.command = object;
                assign.info_name = RX_PAC_K;
                fun(assign.command,type_r,obj_wlan0,assign.info_name,obj,assign.obj_name);

		snprintf(object,sizeof(object),TX_PACKETS_0,l);
                assign.command = object;
                assign.info_name = TX_PAC_K;
                fun(assign.command,type_r,obj_wlan0,assign.info_name,obj,assign.obj_name);
	
		snprintf(object,sizeof(object),SIGNAL_0,l);
                assign.command = object;
                assign.info_name = SIG_K;
                fun(assign.command,type_r,obj_wlan0,assign.info_name,obj,assign.obj_name);

		snprintf(object,sizeof(object),SIGNAL_AVG_0,l);
                assign.command = object;
                assign.info_name = SIG_AVG_K;
                fun(assign.command,type_r,obj_wlan0,assign.info_name,obj,assign.obj_name);

		snprintf(object,sizeof(object),TX_BITRATE_0,l);
                assign.command = object;
                assign.info_name = TX_BIT_K;
                fun(assign.command,type_r,obj_wlan0,assign.info_name,obj,assign.obj_name);
		
		snprintf(object,sizeof(object),RX_BITRATE_0,l);
                assign.command = object;
                assign.info_name = RX_BIT_K;
                fun(assign.command,type_r,obj_wlan0,assign.info_name,obj,assign.obj_name);

			
	}

	
	/* For Wlan1 */

	popen(wlan1_users,"r");
        assign.obj_name = WLAN1_O;

	/* wlan1 object (child of "Wlan object") */
        json_object * obj_user_child2 = json_object_new_object();
        json_object_object_add(obj_user,assign.obj_name,obj_user_child2);

        f2=popen(no_wlan1,"r");
        fgets(pa2,sizeof(pa2),f2);
        num2=atoi(pa2);
        for(l=1;l<=num2;l++)
        {
		/* Gets all the users information, connected to wlan1 interface */ 
                json_object * obj_wlan1 = json_object_new_object();
		
		memset(info,'\0',sizeof(info));
                snprintf(info,sizeof(info),"CLIENT_%d",l);
                assign.obj_name = info;
                json_object_object_add(obj_user_child2,assign.obj_name,obj_wlan1);

                assign.obj_name = WLAN_USERS_O;
		memset(info,'\0',sizeof(info));
                snprintf(info,sizeof(info),STATION_ID_1,l);
                assign.command = info;
                assign.info_name = ID1_K;
                fun(assign.command,type_r,obj_wlan1,assign.info_name,obj,assign.obj_name);

                snprintf(info,sizeof(info),RX_BYTES_1,l);
                assign.command = info;
                assign.info_name = RX_B1_K;
                fun(assign.command,type_r,obj_wlan1,assign.info_name,obj,assign.obj_name);

                snprintf(info,sizeof(info),TX_BYTES_1,l);
                assign.command = info;
                assign.info_name = TX_B1_K;
                fun(assign.command,type_r,obj_wlan1,assign.info_name,obj,assign.obj_name);

                snprintf(info,sizeof(info),RX_PACKETS_1,l);
                assign.command = info;
                assign.info_name = RX_PAC1_K;
                fun(assign.command,type_r,obj_wlan1,assign.info_name,obj,assign.obj_name);

                snprintf(info,sizeof(info),TX_PACKETS_1,l);
                assign.command = info;
                assign.info_name = TX_PAC1_K;
                fun(assign.command,type_r,obj_wlan1,assign.info_name,obj,assign.obj_name);

                snprintf(info,sizeof(info),SIGNAL_1,l);
                assign.command = info;
                assign.info_name = SIG1_K;
                fun(assign.command,type_r,obj_wlan1,assign.info_name,obj,assign.obj_name);

                snprintf(info,sizeof(info),SIGNAL_AVG_1,l);
                assign.command = info;
                assign.info_name = SIG_AVG1_K;
                fun(assign.command,type_r,obj_wlan1,assign.info_name,obj,assign.obj_name);

                snprintf(info,sizeof(info),TX_BITRATE_1,l);
                assign.command = info;
                assign.info_name = TX_BIT1_K;
                fun(assign.command,type_r,obj_wlan1,assign.info_name,obj,assign.obj_name);

                snprintf(info,sizeof(info),RX_BITRATE_1,l);
                assign.command = info;
                assign.info_name = RX_BIT1_K;
                fun(assign.command,type_r,obj_wlan1,assign.info_name,obj,assign.obj_name);


        }

	/* Adds "wlan object" as child to the parent object */
        json_object_object_add(obj,assign.obj_name,obj_user);


}

/* this function gives the data transmit information of eth0 (eth0.1 and eth0.2) */
void get_in_out_info(json_object *obj,char * type_r,struct get_info assign)
{
	/* eth0 object */
	json_object * obj_in_out = json_object_new_object();
	
	/* Child object for "eth0 object" */
	json_object * obj_child = json_object_new_object();

                /* eth0.2's information */
		assign.obj_name = ETH02_O;
                json_object_object_add(obj_in_out,assign.obj_name,obj_child);
		
		assign.obj_name = INOUT_O;
		
		assign.command = ETH02_FRAMES_R_C;
                assign.info_name = ETH02_FRAMES_R_K;
                fun(assign.command,type_r,obj_child,assign.info_name,obj,assign.obj_name);

		assign.command = ETH02_BYTES_R_C;
                assign.info_name = ETH02_BYTES_R_K;
                fun(assign.command,type_r,obj_child,assign.info_name,obj,assign.obj_name);
	
		assign.command = ETH02_BROAD_MULTI_R_C;
                assign.info_name = ETH02_BROAD_MULTI_R_K;
                fun(assign.command,type_r,obj_child,assign.info_name,obj,assign.obj_name);

		assign.command = ETH02_FRAMES_T_C;
                assign.info_name = ETH02_FRAMES_T_K;
		fun(assign.command,type_r,obj_child,assign.info_name,obj,assign.obj_name);

		assign.command = ETH02_BYTES_T_C;
                assign.info_name = ETH02_BYTES_T_K;
                fun(assign.command,type_r,obj_child,assign.info_name,obj,assign.obj_name);

		assign.command = ETH02_DEVICE_C;
                assign.info_name = ETH02_DEVICE_K;
                fun(assign.command,type_r,obj_child,assign.info_name,obj,assign.obj_name);
		
		/* eth0.1's information */
		assign.obj_name = ETH01_O;
                json_object_object_add(obj_in_out,assign.obj_name,obj_child);

                assign.obj_name = INOUT_O;

                assign.command = ETH01_FRAMES_R_C;
                assign.info_name = ETH01_FRAMES_R_K;
                fun(assign.command,type_r,obj_child,assign.info_name,obj,assign.obj_name);

                assign.command = ETH01_BYTES_R_C;
                assign.info_name = ETH01_BYTES_R_K;
                fun(assign.command,type_r,obj_child,assign.info_name,obj,assign.obj_name);

                assign.command = ETH01_BROAD_MULTI_R_C;
                assign.info_name = ETH01_BROAD_MULTI_R_K;
                fun(assign.command,type_r,obj_child,assign.info_name,obj,assign.obj_name);

                assign.command = ETH01_FRAMES_T_C;
                assign.info_name = ETH01_FRAMES_T_K;
                fun(assign.command,type_r,obj_child,assign.info_name,obj,assign.obj_name);

                assign.command = ETH01_BYTES_T_C;
                assign.info_name = ETH01_BYTES_T_K;
                fun(assign.command,type_r,obj_child,assign.info_name,obj,assign.obj_name);
		
		assign.command = ETH01_DEVICE_C;
                assign.info_name = ETH01_DEVICE_K;
                fun(assign.command,type_r,obj_child,assign.info_name,obj,assign.obj_name);

                
		/* Adds "eth0 object" as child to the parent object */
		json_object_object_add(obj,assign.obj_name,obj_in_out);


}


/* This function gets all information regarding Kernel and Memory */
void get_mem_info(json_object *obj,char * type_r,struct get_info assign)
{

	

	/* "kernel object" */
	json_object * obj_ker = json_object_new_object();
        	assign.command = KER_C;
        	assign.info_name = KER_K;
		assign.obj_name = KER_O;
		
		fun(assign.command,type_r,obj_ker,assign.info_name,obj,assign.obj_name);
		
		/*Adds "kernel object" as child to the parent object */
		json_object_object_add(obj,assign.obj_name,obj_ker);	

	

	/* "Memory Object" */
	json_object * obj_ker1 = json_object_new_object();
                assign.obj_name = MEM_O;
	
		assign.command = MEM_TOTAL_C;
                assign.info_name = MEM_TOTAL_K;
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);

                assign.command = MEM_FREE_C;
                assign.info_name = MEM_FREE_K; 
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);
        
                assign.command = MEM_BUF_C;
                assign.info_name = MEM_BUF_K; 
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);
		
		assign.command = MEM_CACHE_C;
                assign.info_name = MEM_CACHE_K;      
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);

		assign.command = MEM_SWAP_CACHE_C;
                assign.info_name = MEM_SWAP_CACHE_K;      
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);

                assign.command = MEM_MAP_C;
                assign.info_name = MEM_MAP_K;
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);

                assign.command = MEM_SHMEM_C;
                assign.info_name = MEM_SHMEM_K;
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);

                assign.command = MEM_KERNEL_STACK_C;
                assign.info_name = MEM_KERNEL_STACK_K;
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);

                assign.command = MEM_PAGE_TABLES_C;
                assign.info_name = MEM_PAGE_TABLES_K;
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);

		assign.command = MEM_VMALLOC_TOTAL_C;
                assign.info_name = MEM_VMALLOC_TOTAL_K;
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);

		assign.command = MEM_VMALLOC_USED_C;
                assign.info_name = MEM_VMALLOC_USED_K;
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);

		assign.command = MEM_VMALLOC_CHUNK_C;
                assign.info_name = MEM_VMALLOC_CHUNK_K;
                fun(assign.command,type_r,obj_ker1,assign.info_name,obj,assign.obj_name);

		/* Adds "memory object" as a child to the parent object */
		json_object_object_add(obj,assign.obj_name,obj_ker1);

}


/* This function provides informations like uptime,load-avg */
void get_other_info(json_object *obj,char * type_r,struct get_info assign)
{
	/* Object for "other information" */
		json_object * obj_other = json_object_new_object();
                assign.obj_name = OTHER_O;

		/* Uptime information */
		assign.command = UPTIME_C;
                assign.info_name = UPTIME_K;
                fun(assign.command,type_r,obj_other,assign.info_name,obj,assign.obj_name); 

		/* Load-avg information */
                assign.command = LOADAVG_C;
                assign.info_name = LOADAVG_K; 
                fun(assign.command,type_r,obj_other,assign.info_name,obj,assign.obj_name);
                
		/* Adds "other information object" as a child to the parent object */
		json_object_object_add(obj,assign.obj_name,obj_other);

	
}
