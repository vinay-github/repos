#! /bin/sh

# Date: 17 Feb 2014

# This script runs "horst"  to catch information of all 
# the wifi devices within our AP's range.




#. ./range.conf
WRT=/tmp/sh.txt
INTERFACE=$1;
#NET_ANALZ=`which net_analz`;
NET_ANALZ="./net_analz";
MAC=`/sbin/ifconfig $INTERFACE | grep HWaddr | awk '{ print $5 }'`;
main()
{
	/usr/bin/killall horst > /dev/null 2>&1;
	if [ ! $INTERFACE ]; then
		echo "Please pass interface name as argument";
		exit;
	fi	
		
	iw dev $INTERFACE interface add mon0 type monitor > /dev/null 2>&1;
	/bin/horst -i mon0 -e $MAC -o $WRT -q | $NET_ANALZ & 
	CHECK=`ps | grep -i horst | grep -v grep`;
	if [ ! "$CHECK" ]; then
		echo "Horst failed to start"
	else
		echo "Horst started successfully"
	fi
	
}
main $*
