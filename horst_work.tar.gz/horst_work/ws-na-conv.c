/* This c-file will convert the raw data to json structured data */


#include <stdio.h>
#include <stdlib.h>
#include <json/json.h>
#include <string.h>
#include "na.h"

extern struct net_analz analz;

int conv_horst_info(json_object *,struct json_structure);
void add_to_obj(char *,json_object *,char *);
void add_to_obj_int(int,json_object *,char *);


int conv_net_analz()
{
	int res;
	/* get Horst(Network Analyser) information */
	res = get_all_na_data();
	return NA_SUCCESS;
}

int process_conv()
{
	FILE *fp;
        struct json_structure jstruct;
        int res;

	json_object * na_obj = json_object_new_object();

        res = conv_horst_info(na_obj,jstruct);

        if((fp=fopen(OUTPUT_FILE,"w")) !=NULL) {
                fprintf(fp,"%s\n",json_object_to_json_string(na_obj));
                fclose(fp);
        }
        json_object_put(na_obj);
        return NA_SUCCESS;
}

int  conv_horst_info(json_object *na_obj,struct json_structure jstruct) {
	
	char obj_name[OBJECT_SIZE];
	int i;
	json_object *h_info = json_object_new_object();
	
	if ( analz.no_of_devices == 0 )
		return NA_SUCCESS;

	for(i=0; i< analz.no_of_devices; i++) {
	
		json_object * cli_obj = json_object_new_object();

                snprintf(obj_name,sizeof(obj_name),DEVICE,i+1);
                jstruct.object = obj_name;
                json_object_object_add(h_info,jstruct.object,cli_obj);

		jstruct.value = analz.horstinfo[i].protype;	
                jstruct.keyword = PROTYPE_K;
                add_to_obj(jstruct.value,cli_obj,jstruct.keyword);

		jstruct.value = analz.horstinfo[i].src_mac;
                jstruct.keyword = SRCMAC_K;
                add_to_obj(jstruct.value,cli_obj,jstruct.keyword);

		jstruct.value = analz.horstinfo[i].client_mac;
                jstruct.keyword = CLIENTMAC_K;
                add_to_obj(jstruct.value,cli_obj,jstruct.keyword);

		jstruct.value = analz.horstinfo[i].bssid;
                jstruct.keyword = BSSID_K;
                add_to_obj(jstruct.value,cli_obj,jstruct.keyword);
	
		jstruct.value = analz.horstinfo[i].packet_type;
                jstruct.keyword = PAC_TYPE_K;
                add_to_obj(jstruct.value,cli_obj,jstruct.keyword);
	
		jstruct.value = analz.horstinfo[i].signal;
                jstruct.keyword = SIGNAL_K;
                add_to_obj(jstruct.value,cli_obj,jstruct.keyword);

		jstruct.value = analz.horstinfo[i].noise;
                jstruct.keyword = NOISE_K;
                add_to_obj(jstruct.value,cli_obj,jstruct.keyword);

		jstruct.value = analz.horstinfo[i].snr;
                jstruct.keyword = SNR_K;
                add_to_obj(jstruct.value,cli_obj,jstruct.keyword);
	
		jstruct.value = analz.horstinfo[i].len;
                jstruct.keyword = LEN_K;
                add_to_obj(jstruct.value,cli_obj,jstruct.keyword);

		jstruct.value = analz.horstinfo[i].rate;
                jstruct.keyword = RATE_K;
                add_to_obj(jstruct.value,cli_obj,jstruct.keyword);

		jstruct.value = analz.horstinfo[i].tsf;
                jstruct.keyword = TSF_K;
                add_to_obj(jstruct.value,cli_obj,jstruct.keyword);

		jstruct.value = analz.horstinfo[i].essid;
                jstruct.keyword = ESSID_K;
                add_to_obj(jstruct.value,cli_obj,jstruct.keyword);

		jstruct.value = analz.horstinfo[i].mode;
                jstruct.keyword = MODE_K;
                add_to_obj(jstruct.value,cli_obj,jstruct.keyword);

		jstruct.value = analz.horstinfo[i].channel;
                jstruct.keyword = CHANNEL_K;
                add_to_obj(jstruct.value,cli_obj,jstruct.keyword);

		jstruct.value = analz.horstinfo[i].timestamp;
                jstruct.keyword = TIMESTAMP_K;
                add_to_obj(jstruct.value,cli_obj,jstruct.keyword);

	}
	jstruct.object = HORST_INFO;
        json_object_object_add(na_obj,jstruct.object,h_info);

}


/* adds string data to json object */
void add_to_obj(char *key,json_object * obj,char *tmp)
{
        json_object *st = json_object_new_string(key);
        json_object_object_add(obj,tmp,st);

}

/* adds int data to json object */
void add_to_obj_int(int key,json_object * obj,char *tmp)
{
        json_object *st = json_object_new_int(key);
        json_object_object_add(obj,tmp,st);
}

/*--------------- End of File ----------------*/

