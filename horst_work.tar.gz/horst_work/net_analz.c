#include <stdio.h>
#include "na.h"
int main() {
	int res;
	res = conv_net_analz();
	return NA_SUCCESS;
}
