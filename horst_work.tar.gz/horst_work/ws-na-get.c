/* 	This file used to gets information from horst(Network Analyser),
	"stdin" should be the input to this program.  */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include "na.h"


struct net_analz analz;


int get_na_info(struct horst_info *horstinfo)
{
	FILE *fp,*fp2;
	int fd[2],n;
	char buf[MAX_CLIENTS_SCAN], finfo[MAX_CLIENTS_SCAN];
	char protype[PROTYPE_SIZE],src_mac[MAC_SIZE],client_mac[MAC_SIZE],bssid[MAC_SIZE],packet_type[PACKETTYPE_SIZE];
	char signal[SIGNAL_SIZE], noise[NOISE_SIZE], snr[SNR_SIZE] , len[LEN_SIZE], rate[RATE_SIZE], tsf[TSF_SIZE];
	char essid[SSID_SIZE], mode[MODE_SIZE], channel[CHANNEL_SIZE],wlan_wep[WEP_SIZE],ip_src[IP_SRC],ip_dst[IP_SRC];
	char olsr_nigh[OLSR_NIGH], olsr_type[OLSR_TYPE], timestamp[TIMESTAMP_SIZE];

	int i=0,j=0,ms_time=0,ms_pre_time=0;
	pid_t pid;
	struct timeval tp;
        
	gettimeofday(&tp,NULL);
	ms_pre_time = (tp.tv_sec);
	
	while(fgets(buf,sizeof(buf),stdin)) {
		
		sscanf(buf, "%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
		protype, src_mac, client_mac, bssid, packet_type, signal, noise, snr, len, rate, tsf,
		essid, mode, channel, wlan_wep, ip_src, ip_dst, olsr_nigh, olsr_type, timestamp);
		
        	protype[strlen(protype)-1]='\0';
        	strncpy(horstinfo[i].protype, protype, sizeof(horstinfo[i].protype));
	
		src_mac[strlen(src_mac)-1]='\0';
        	strncpy(horstinfo[i].src_mac, src_mac, sizeof(horstinfo[i].src_mac));
	
		client_mac[strlen(client_mac)-1]='\0';
        	strncpy(horstinfo[i].client_mac, client_mac, sizeof(horstinfo[i].client_mac));

		bssid[strlen(bssid)-1]='\0';
        	strncpy(horstinfo[i].bssid, bssid, sizeof(horstinfo[i].bssid));

		packet_type[strlen(packet_type)-1]='\0';
        	strncpy(horstinfo[i].packet_type, packet_type, sizeof(horstinfo[i].packet_type));

		signal[strlen(signal)-1]='\0';
        	strncpy(horstinfo[i].signal, signal, sizeof(horstinfo[i].signal));

		noise[strlen(noise)-1]='\0';
        	strncpy(horstinfo[i].noise, noise, sizeof(horstinfo[i].noise));

		snr[strlen(snr)-1]='\0';
        	strncpy(horstinfo[i].snr, snr, sizeof(horstinfo[i].snr));

		len[strlen(len)-1]='\0';
        	strncpy(horstinfo[i].len, len, sizeof(horstinfo[i].len));

        	strncpy(horstinfo[i].rate, rate, sizeof(horstinfo[i].rate));
	
		tsf[strlen(tsf)-1]='\0';
        	strncpy(horstinfo[i].tsf, tsf, sizeof(horstinfo[i].tsf));

		essid[strlen(essid)-1]='\0';
        	strncpy(horstinfo[i].essid, essid, sizeof(horstinfo[i].essid));

		mode[strlen(mode)-1]='\0';
        	strncpy(horstinfo[i].mode, mode, sizeof(horstinfo[i].mode));

        	channel[strlen(channel)-1]='\0';
        	strncpy(horstinfo[i].channel, channel, sizeof(horstinfo[i].channel));

        	wlan_wep[strlen(wlan_wep)-1]='\0';
        	strncpy(horstinfo[i].wlan_wep, wlan_wep, sizeof(horstinfo[i].wlan_wep));

        	ip_src[strlen(ip_src)-1]='\0';
        	strncpy(horstinfo[i].ip_src, ip_src, sizeof(horstinfo[i].ip_src));

        	ip_dst[strlen(ip_dst)-1]='\0';
        	strncpy(horstinfo[i].ip_dst, ip_dst, sizeof(horstinfo[i].ip_dst));

        	olsr_nigh[strlen(olsr_nigh)-1]='\0';
        	strncpy(horstinfo[i].olsr_nigh, olsr_nigh, sizeof(horstinfo[i].olsr_nigh));

        	olsr_type[strlen(olsr_type)-1] ='\0';
        	strncpy(horstinfo[i].olsr_type, olsr_type, sizeof(horstinfo[i].olsr_type));
 
        	strncpy(horstinfo[i].timestamp, timestamp, sizeof(horstinfo[i].timestamp));
	
		i++;
		gettimeofday(&tp,NULL);
                ms_time = (tp.tv_sec);
		if( (j < MAX_DATA_PER) && (ms_time < (ms_pre_time + TIME_INTERVAL)) )
			j++;
		else
		{
			ms_pre_time = ms_time;
			pid = fork();
			if(pid == 0)
			{	
				int res;
				analz.no_of_devices = i;		
				res = process_conv();
				exit(0);
			}
			else if(pid == -1)
			{
				return NA_FAILURE;
			}
			ms_time=0;
			j=0;
			i=0;
		}

	}	
	return NA_SUCCESS;
}


int get_all_na_data() {
	int res;
	res = get_na_info(analz.horstinfo);
	return NA_SUCCESS;
}
