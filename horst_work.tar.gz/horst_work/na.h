#define PROTYPE_SIZE		16
#define MAC_SIZE		32
#define TSF_SIZE		48
#define SSID_SIZE		32
#define TIMESTAMP_SIZE		48
#define KEYWORD_SIZE		16
#define VALUE_SIZE		32
#define OBJECT_SIZE		16
#define SIGNAL_SIZE		8
#define MAX_CLIENTS_SCAN	1200
#define NA_SUCCESS		0;
#define NA_FAILURE		-1;

#define HORST_DATA_FILE		"/tmp/sh.txt"
#define OUTPUT_FILE		"/tmp/nearbydev.json"
#define PACKETTYPE_SIZE		4
#define NOISE_SIZE		4
#define SNR_SIZE		4
#define LEN_SIZE		4
#define RATE_SIZE		4
#define MODE_SIZE		4
#define CHANNEL_SIZE		4
#define WEP_SIZE		4
#define IP_SRC			32
#define IP_DST			32
#define OLSR_TYPE		4
#define OLSR_NIGH		4

#define MAX_DATA_PER		74
#define TIME_INTERVAL		10

struct horst_info
{
	char protype[PROTYPE_SIZE];
	char src_mac[MAC_SIZE];
	char client_mac[MAC_SIZE];
	char bssid[MAC_SIZE];
	char packet_type[PACKETTYPE_SIZE];
	char signal[SIGNAL_SIZE];
	char noise[NOISE_SIZE];
	char snr[SNR_SIZE];
	char len[LEN_SIZE];
	char rate[RATE_SIZE];
	char tsf[TSF_SIZE];
	char essid[SSID_SIZE];
	char mode[MODE_SIZE];
	char channel[CHANNEL_SIZE];
	char wlan_wep[WEP_SIZE];
	char ip_src[IP_SRC];
	char ip_dst[IP_SRC];
	char olsr_type[OLSR_TYPE];
	char olsr_nigh[OLSR_NIGH];
	char timestamp[TIMESTAMP_SIZE];
};

struct net_analz
{
	int no_of_devices;
	struct horst_info horstinfo[MAX_CLIENTS_SCAN];
};

struct json_structure
{
	char *object;
	char *keyword;
	char *value;
	int val;
};


#define HORST_INFO		"HORST_NA_INFO"

#define DEVICE 			"DEVICE_%d"
#define PROTYPE_K 		"PROTYPE"
#define SRCMAC_K 		"SRC_MAC"
#define CLIENTMAC_K 		"CLIENT_MAC"
#define BSSID_K 		"BSSID"
#define PAC_TYPE_K		"PACKET_TYPE"
#define SIGNAL_K		"SIGNAL"
#define NOISE_K			"NOISE"
#define SNR_K			"SIGNAL_NOISE_RATIO"
#define LEN_K			"LENGTH"
#define RATE_K			"RATE"
#define TSF_K			"TSF"
#define ESSID_K			"ESSID"
#define MODE_K			"MODE"
#define CHANNEL_K		"CHANNEL"
#define TIMESTAMP_K		"TIMESTAMP"


